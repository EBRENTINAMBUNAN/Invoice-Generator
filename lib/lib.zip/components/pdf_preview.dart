import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path_provider/path_provider.dart';

class PDFPreviewPage extends StatefulWidget {
  final Uint8List pdfData;
  final String fileName;

  const PDFPreviewPage({super.key, required this.pdfData, required this.fileName});

  @override
  State<PDFPreviewPage> createState() => _PDFPreviewPageState();
}

class _PDFPreviewPageState extends State<PDFPreviewPage> {
  String? tempPath;

  @override
  void initState() {
    super.initState();
    _writeTempFile();
  }

  Future<void> _writeTempFile() async {
    final dir = await getTemporaryDirectory();
    final filePath = '${dir.path}/${widget.fileName}';
    final file = File(filePath);
    await file.writeAsBytes(widget.pdfData);
    setState(() {
      tempPath = file.path;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (tempPath == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Preview Invoice"),
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: () {
              Navigator.pop(context, true); // Return true to confirm export
            },
          ),
        ],
      ),
      body: PDFView(
        filePath: tempPath!,
      ),
    );
  }
}
